
Meteor.startup(function () {
 
/*console.log('inicia');
	var CRON1 = new CRONjob();

	var task = function (ready) {
	  //...some code here
	  console.log('inicia cron');
	  var rol = {
	      nombre: 'cron job'
	    
	    };

	    //var rolId = Roles.insert(rol);
	}




	CRON1.setInterval(task, 30*60*1000);*/

});

