Template.dataTables.rendered = function(){

    // Initialize dataTables
    $('.dataTables-example').dataTable({
        "dom": 'T<"clear">lfrtip'
    });

};