Template.pageHeading.helpers({

    // Route for Home link in breadcrumbs
    home: 'pageOne'

});