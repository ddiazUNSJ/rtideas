// Template.modalNombre.events({
//   'click #save': function(e) {
//     e.preventDefault();
//      Session.set(nombreArchivo,"cualquiera.png");
   
//     var nombreA = {
//       nombre: $('#nombreArch').val()
//     };

//     Meteor.call('nombreRepetido', Meteor.userId(),nombreA, function(error, result) {
//       if (error) {
//         alert(error);
//       }
//       else{ 
        
//         Session.set("nombreArchivo", nombreA+".png");
//         Modal.hide('modalNombre');}
//     });



//   }
// });
