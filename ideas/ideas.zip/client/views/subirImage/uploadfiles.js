// import { Template } from 'meteor/templating';
// import { ReactiveVar } from 'meteor/reactive-var';
// import { Images } from '/both/lib/image.collection.js';
// //import { Schema } from '/both/collections/inscripcion.js';

// import './uploadfiles.html';
//Trae todas la imagenes y los coloca en el objeto uploadedFiles
// Template.uploadedFiles.helpers({
//   uploadedFiles: function () {
//     return Images.find();
//   }
// });

