

Template.eliminarActualizar.events({
  'click .delete': function () {
    swal("Eliminar usuario");
   
  },

  'click .update': function () {
    swal("Actualizar usuario");
   
  }
  
});